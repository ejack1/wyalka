 <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
	
	<!-- vector map CSS -->
    <link href="<?php echo base_url()."assets/"; ?>vendors4/vectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css" />

    <!-- Toggles CSS -->
    <link href="<?php echo base_url()."assets/"; ?>vendors4/jquery-toggles/css/toggles.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url()."assets/"; ?>/vendors4/jquery-toggles/css/themes/toggles-light.css" rel="stylesheet" type="text/css">
	 

    <!-- ION CSS -->
    <link href="<?php echo base_url()."assets/"; ?>vendors4/ion-rangeslider/css/ion.rangeSlider.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url()."assets/"; ?>vendors4/ion-rangeslider/css/ion.rangeSlider.skinHTML5.css" rel="stylesheet" type="text/css">

    <!-- select2 CSS -->
    <link href="<?php echo base_url()."assets/"; ?>vendors4/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />

    <!-- Pickr CSS -->
    <link href="<?php echo base_url()."assets/"; ?>vendors4/pickr-widget/dist/pickr.min.css" rel="stylesheet" type="text/css" />

    <!-- Daterangepicker CSS -->
    <link href="<?php echo base_url()."assets/"; ?>vendors4/daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css" />
	<!-- Toastr CSS -->
    <link href="<?php echo base_url()."assets/"; ?>vendors4/jquery-toast-plugin/dist/jquery.toast.min.css" rel="stylesheet" type="text/css">

    <!-- Custom CSS -->
    <link href="<?php echo base_url()."assets/"; ?>dist/css/style.css" rel="stylesheet" type="text/css">
	
	
	
	
	
	
	 <!-- jQuery -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>vendors4/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Jasny-bootstrap  JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/jasny-bootstrap/dist/js/jasny-bootstrap.min.js"></script>

    <!-- Slimscroll JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>dist/js/jquery.slimscroll.js"></script>

    <!-- Fancy Dropdown JS -->
    <script src="<?php echo base_url()."assets/"; ?>dist/js/dropdown-bootstrap-extended.js"></script>

    <!-- Ion JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/ion-rangeslider/js/ion.rangeSlider.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>dist/js/rangeslider-data.js"></script>

    <!-- Toggles JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/jquery-toggles/toggles.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>dist/js/toggle-data.js"></script>

    <!-- Select2 JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/select2/dist/js/select2.full.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>dist/js/select2-data.js"></script>

    <!-- Bootstrap Tagsinput JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.html"></script>

    <!-- Bootstrap Input spinner JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/bootstrap-input-spinner/src/bootstrap-input-spinner.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>dist/js/inputspinner-data.js"></script>

    <!-- Pickr JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/pickr-widget/dist/pickr.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>dist/js/pickr-data.js"></script>

    <!-- Daterangepicker JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/moment/min/moment.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>vendors4/daterangepicker/daterangepicker.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>dist/js/daterangepicker-data.js"></script>

    <!-- FeatherIcons JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>dist/js/feather.min.js"></script>

    <!-- Toggles JavaScript -->
    <script src="<?php echo base_url()."assets/"; ?>vendors4/jquery-toggles/toggles.min.js"></script>
    <script src="<?php echo base_url()."assets/"; ?>dist/js/toggle-data.js"></script>

	
	
	
	

   
   
