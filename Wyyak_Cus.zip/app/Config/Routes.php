<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('login');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('lang/{locale}', 'Language::index');
$routes->get('/', 'Home::index');
$routes->get('/login', 'Home::login');
$routes->get('/dashboard', 'Home::dashboard');
$routes->get('/logout', 'Home::logout');
$routes->get('/register', 'Home::register');
$routes->get('/dashboard', 'Home::dashboard');
$routes->get('/edit-profile', 'Home::editprofile');
$routes->get('/update-password', 'Home::changepassword');


$routes->get('/add-ticket', 'Tickets::addticket');
$routes->get('/all-tickets', 'Tickets::alltickets');

$routes->get('/add-shipment', 'Shipments::addshipment');
$routes->get('/add-bulk-shipment', 'Shipments::addbulkshipment');
$routes->get('/import-return-shipment', 'Shipments::importreturnshipment');
$routes->get('/today-manifest', 'Shipments::todaymanifest');
$routes->get('/today-order', 'Shipments::todayorder');
$routes->get('/track-order', 'Shipments::trackorder');
$routes->get('/all-shipments', 'Shipments::allshipments');
$routes->get('/all-shipments/(:any)', 'Shipments::allshipments/$1');

$routes->get('/account-transaction', 'ReportManagement::accounttransaction');
$routes->get('/client-performance', 'Home::clientperformance');

$routes->get('/add-pickup-request', 'PickupManagement::addpickuprequest');
$routes->match(["get","post"],'/add-pickup-location', 'PickupManagement::addpickuplocation');
$routes->get('/show-pickup-request', 'PickupManagement::showpickuprequest');
$routes->get('/show-pickup-location', 'PickupManagement::showpickuplocation');
$routes->get('/delete-pickup-location/(:any)', 'PickupManagement::deletepickuplocation/$1');

$routes->get('/notification-list', 'Notifications::notificationlist');

$routes->get('/api-list', 'Home::apiguide');
$routes->get('/support', 'Home::support');
$routes->get('/track-shipment', 'Home::trackshipment');


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
