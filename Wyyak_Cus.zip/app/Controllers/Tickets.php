<?php

namespace App\Controllers;
use App\Libraries\Generic;
use App\Models\TicketsModel;

use CodeIgniter\Database\Config;
use Config\App;
use Config\Database;
use DateTime;

class Tickets extends BaseController
{

    private $datahdr = array();
    private $data = array();
    private $dataftr = array();

    public function __construct()
    { 
        $generic = new Generic();
        $this->dataftr["social"] = $generic->getsociallinks(); 
       
    }



    public function addticket()
    {
        if ($this->generic->isLoggedInuser()) {

            $title = "Add Ticket";
            $details = [
                'tab' => 'Tickets',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);
            $id = $this->session->get("id");

            $form_errors = array();
            if ($this->request->getMethod() == 'post') {

                $rules = [
                    'inputReason' => [
                        'rules' => 'required',
                        'errors' => [
                            'required' => "Reason is Required"
                        ]
                    ],
                    'inputAWB' => [
                        'rules' => 'required',
                        'errors' => [
                            'required' => "AWB No. is Required",
                        ]
                    ],
                    'inputDesc' => [
                        'rules' => 'required',
                        'errors' => [
                            'required' => "Description is Required",
                        ]
                    ],




                ];



                if (!$this->validate($rules)) {
                    $form_errors = $this->validator;
                    $this->data['form_errors'] = $form_errors;
                } else {
                    $TicketsModel = new TicketsModel();
                    
                    $id = $TicketsModel->getlastrow();



                    $upload_data = [
                        'subject' => $this->request->getPost('inputReason'),
                        'awb_no' => $this->request->getPost('inputAWB'),
                        'message' => $this->request->getPost('inputDesc'),
                        'user_id' => $this->session->get("id"),
                        'name' => $this->session->get("name"),
                        'mobile' => $this->session->get("phone"),
                        'email' => $this->session->get("email"),
                        'entry_date' => date("Y-m-d"),
                        'ticket_no' => $id+1,



                    ];




                    $TicketsModel->insert( $upload_data);









                    return redirect()->back()->with("success", "Ticket has been created Successfully");
                }
            }

            echo view('user/header', $this->datahdr);
            echo view("user/Tickets/addticket", $this->data);

            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }

    public function alltickets()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "All Tickets";
            $details = [
                'tab' => 'Tickets',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);

            $TicketsModel = new TicketsModel();
            $this->data["tickets"] = $TicketsModel->select(["id","awb_no","ticket_no","subject","message","ticket_status","entry_date"])->where(["user_id"=>$this->session->get("id"),"q_type"=>"Q"])->find();


            echo view('user/header', $this->datahdr);
            echo view('user/Tickets/alltickets', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }


    private function getMenuTemplate($details)
    {
        $this->data['details'] = $details;
        return view('user/user_menu', $this->data);
    }

    private function getTopTemplate($title)
    {
        $this->data['title'] = $title;
        $db = \Config\Database::connect();
        $result = $db->query("SELECT logo FROM site_config");
        $logo = $result->getResultArray();
        $this->data["logo"] = $logo[0]["logo"];
        return view('user/user_top', $this->data);
    }
}
