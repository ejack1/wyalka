<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use App\Models\CountryCityModel;
use App\Libraries\Generic;

use CodeIgniter\Database\Config;
use Config\App;
use Config\Database;
use DateTime;

class Home extends BaseController
{

    private $datahdr = array();
    private $data = array();
    private $dataftr = array();


    public function __construct()
    {
        $generic = new Generic();
        $this->dataftr["social"] = $generic->getsociallinks();
    }


    public function index()
    {
        if ($this->generic->isLoggedInuser()) {
            return redirect()->to(site_url('/dashboard'));
        } else {
            return redirect()->to(site_url('/login'));
        }
    }

    public function userregister()
    {
        echo view("user/register");
    }

    public function login()
    {

        helper(['form']);
        // echo "<pre>";
        // echo "hello";
        // echo "<pre>";
        // exit;
        $db = \Config\Database::connect();
        $result = $db->query("SELECT logo FROM site_config");
        $logo = $result->getResultArray();
        $this->data["logo"] = $logo[0]["logo"];

        if ($this->request->getMethod() == 'post') {
            //     echo "<pre>";
            // echo "hello";
            // echo "<pre>";
            // exit;

            $rules = [
                'email' => 'required|valid_email',
                'password' => 'required'
            ];

            $errors = [
                'password' => [
                    'validateUser' => 'Wrong Credentials'
                ]
            ];

            if (!$this->validate($rules, $errors)) {
                $this->data['validation'] = $this->validator;
            } else {

                // now authenticate user for credentials provided
                $model = new CustomerModel();

                $criteria = [
                    'email' => $this->request->getVar('email'),
                    'password' => md5($this->request->getVar('password'))
                ];

                $user = $model->where($criteria)
                    // ->whereIn('adm_id', [1])
                    ->first();

                if (!empty($user)) {
                    $this->generic->startSessionuser($user);
                    return redirect()->to(site_url('/dashboard'));
                } else {
                    
                    $this->data['errors'] = array('Wrong Credentials');
                }
            }
        }


        echo view('login', $this->data);
    }



    public function dashboard()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Dashboard";
            $details = [
                'tab' => 'Dashboard',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/dashboard', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function register()
    {
        $form_errors = array();
        if ($this->request->getMethod() == 'post') {

            $rules = [
                'inputEmail' => 'required|is_unique[users.email]',
                'inputName' => 'required',
                'inputPassword' => 'required',
                'inputPhone' => 'required',
                'inputPhoneAlt' => 'required',
                'inputCompany' => 'required',
                'inputAddress' => 'required',
                'inputCity' => 'required',
                'inputUIdAccount' => 'required',
                'inputBankName' => 'required',
                'inputBankAccountNumber' => 'required',
                'inputBankIban' => 'required',


            ];

            if (!$this->validate($rules)) {
                $form_errors = $this->validator;
                $this->data['form_errors'] = $form_errors;
            } else {


                $upload_data = [
                    'email' => $this->request->getPost('inputEmail'),
                    'password' => $this->request->getPost('inputPassword'),
                    'name' => $this->request->getPost('inputName'),
                    'mobile' => $this->request->getPost('inputPhone'),
                    'mobile_alt' => $this->request->getPost('inputPhoneAlt'),
                    'company' => $this->request->getPost('inputCompany'),
                    'city' => $this->request->getPost('inputCity'),
                    'address' => $this->request->getPost('inputAddress'),
                    'uid_account' => $this->request->getPost('inputUIdAccount'),
                    'bank_name' => $this->request->getPost('inputBankName'),
                    'bank_account_num' => $this->request->getPost('inputBankAccountNumber'),
                    'bank_iban' => $this->request->getPost('inputBankIban'),


                ];



                $UserModel = new CustomerModel();
                $UserModel->insert($upload_data);




                $this->session->setFlashdata("success", "User has been Registered Successfully");




                return redirect()->to(site_url('/user/register'));
            }
        }

        echo view("register", $this->data);
    }
    public function editprofile()
    {
        if ($this->generic->isLoggedInuser()) {

            $title = "Edit Profile";
            $details = [
                'tab' => 'profile',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);
            $form_errors = array();
            if ($this->request->getMethod() == 'post') {

                $rules = [
                    'inputEmail' => 'required|is_unique[users.email]',
                    'inputName' => 'required',
                    'inputPassword' => 'required',
                    'inputPhone' => 'required',
                    'inputPhoneAlt' => 'required',
                    'inputCompany' => 'required',
                    'inputAddress' => 'required',
                    'inputCity' => 'required',
                    'inputUIdAccount' => 'required',
                    'inputBankName' => 'required',
                    'inputBankAccountNumber' => 'required',
                    'inputBankIban' => 'required',


                ];

                if (!$this->validate($rules)) {
                    $form_errors = $this->validator;
                    $this->data['form_errors'] = $form_errors;
                } else {


                    $upload_data = [
                        'email' => $this->request->getPost('inputEmail'),
                        'password' => $this->request->getPost('inputPassword'),
                        'name' => $this->request->getPost('inputName'),
                        'mobile' => $this->request->getPost('inputPhone'),
                        'mobile_alt' => $this->request->getPost('inputPhoneAlt'),
                        'company' => $this->request->getPost('inputCompany'),
                        'city' => $this->request->getPost('inputCity'),
                        'address' => $this->request->getPost('inputAddress'),
                        'uid_account' => $this->request->getPost('inputUIdAccount'),
                        'bank_name' => $this->request->getPost('inputBankName'),
                        'bank_account_num' => $this->request->getPost('inputBankAccountNumber'),
                        'bank_iban' => $this->request->getPost('inputBankIban'),


                    ];



                    $UserModel = new CustomerModel();
                    $UserModel->insert($upload_data);




                    $this->session->setFlashdata("success", "User has been Registered Successfully");




                    return redirect()->to(site_url('/user/register'));
                }
            }

            echo view('user/header', $this->datahdr);
            echo view("user/edit-profile", $this->data);

            echo view('user/footer', $this->datahdr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function changepassword()
    {
        if ($this->generic->isLoggedInuser()) {

            $title = "Change Password";
            $details = [
                'tab' => 'change',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);
            $id = $this->session->get("id");

            $form_errors = array();
            if ($this->request->getMethod() == 'post') {

                $rules = [
                    'inputOldPassword' => [
                        'rules' => 'required',
                        'errors' => [
                            'required' => "Old Password is Required"
                        ]
                    ],
                    'inputNewPassword' => [
                        'rules' => 'required|differs[inputOldPassword]',
                        'errors' => [
                            'required' => "New Password is Required",
                            'differs' => "New Password cannot be same as old password"
                        ]
                    ],
                    'inputConfirmPassword' => [
                        'rules' => 'required|matches[inputNewPassword]',
                        'errors' => [
                            'required' => "Confirm Password is Required",
                            'matches' => "New Password does not matches confirm password"
                        ]
                    ],




                ];



                if (!$this->validate($rules)) {
                    $form_errors = $this->validator;
                    $this->data['form_errors'] = $form_errors;
                } else {
                    $UserModel = new CustomerModel();
                    $password = $UserModel->select("password")->where(["id" => $id])->first();

                    if (md5($this->request->getPost('inputOldPassword')) == $password["password"]) {


                        $upload_data = [
                            'password' => md5($this->request->getPost('inputConfirmPassword')),



                        ];




                        $UserModel->update($id, $upload_data);









                        return redirect()->back()->with("success", "Password has been changed Successfully");
                    } else {
                        return redirect()->back()->with("failure", "Old Password is incorrect");
                    }
                }
            }

            echo view('user/header', $this->datahdr);
            echo view("user/changepassword", $this->data);

            echo view('user/footer', $this->datahdr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function apiguide()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Api List";
            $details = [
                'tab' => 'Api',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/apilist', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function clientperformance()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Performance";
            $details = [
                'tab' => 'Performance',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/performance', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function support()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Support";
            $details = [
                'tab' => 'Support',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/support', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function trackshipment()
    {
        if ($this->generic->isLoggedInuser()) {

            echo view('user/shipmentrack', $this->data);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function getcities()
    {
        
        if ($_POST["country"]) {


            $CountryCityModel = new CountryCityModel();
            $data = $CountryCityModel->select(["id", "city"])->where('city !=', " ")->where([ "country" => $_POST["country"]])->findAll();
            $cities = '<option value="">Select City</option>';
            for($i = 0 ; $i<sizeof($data); $i++){
                $cities .= '<option value="'.$data[$i]["id"].'">'.$data[$i]["city"].'</option>';
            }

            echo json_encode($cities);
        }
    }


    private function getMenuTemplate($details)
    {
        $this->data['details'] = $details;
        return view('user/user_menu', $this->data);
    }

    private function getTopTemplate($title)
    {
        $this->data['title'] = $title;
        $db = \Config\Database::connect();
        $result = $db->query("SELECT logo FROM site_config");
        $logo = $result->getResultArray();
        $this->data["logo"] = $logo[0]["logo"];
        return view('user/user_top', $this->data);
    }
    function logout()
    {
        $this->session->destroy();
        return redirect()->to(site_url('Home/index'));
    }
}
