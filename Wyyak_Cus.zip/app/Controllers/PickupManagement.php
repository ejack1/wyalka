<?php

namespace App\Controllers;

use App\Models\CountryCityModel;
use App\Models\PickupLocationModel;
use App\Libraries\Generic;
use CodeIgniter\Database\Config;
use Config\App;
use Config\Database;
use DateTime;

class PickupManagement extends BaseController
{

    private $datahdr = array();
    private $data = array();
    private $dataftr = array();

    public function __construct()
    { 
        $generic = new Generic();
        $this->dataftr["social"] = $generic->getsociallinks(); 
       
    }



    public function addpickuprequest()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Add Pickup Request";
            $details = [
                'tab' => 'Pickuprequest',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/PickupManagement/addpickuprequest', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function addpickuplocation()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Add Pickup Location";
            $details = [
                'tab' => 'Pickup',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            
            $form_errors = array();
            if ($this->request->getMethod() == 'post') {

                $rules = [
                    'sel_country' => [
                        'rules' => 'required',
                        'errors' => [
                            'required' => "Country is Required"
                        ]
                    ],
                    'city_id' => [
                        'rules' => 'required',
                        'errors' => [
                            'required' => "City is Required",
                        ]
                    ],
                   
                    




                ];



                if (!$this->validate($rules)) {
                    $form_errors = $this->validator;
                    $this->data['form_errors'] = $form_errors;
                } else {

                    $upload_data = [
                        "location_number"=> "ADD_".date("Ymd").date("H"),
                        "city_id" => $this->request->getPost("city_id"),
                        "lang" => $this->request->getPost("lang"),
                        "lat" => $this->request->getPost("lat"),
                    ];


                    $PickupLocationModel = new PickupLocationModel();
                  
                    $PickupLocationModel->insert($upload_data);






                    return redirect()->to(site_url('/show-pickup-location'))->with("success","Location Added Successfully");
                    }
                }
            




            $CountryCityModel = new CountryCityModel();
            $this->data["country"] = $CountryCityModel->select(["id","country"])->where(["city"=>"","state"=>""])->findAll();

            echo view('user/header', $this->datahdr);
            echo view('user/PickupManagement/addpickuplocation', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function showpickuprequest()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Show Pickup Request";
            $details = [
                'tab' => 'Pickuprequest',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/PickupManagement/showpickuprequest', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function showpickuplocation()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Show Pickup Request";
            $details = [
                'tab' => 'Pickup',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);

            $db = \Config\Database::connect();
            $result = $db->query("SELECT * ,(SELECT city FROM country WHERE country.id=pl.city_id) as city_name FROM pickup_loaction as pl ");
            $this->data["locations"] = $result->getResultArray();
            



            echo view('user/header', $this->datahdr);
            echo view('user/PickupManagement/showpickuplocation', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function deletepickuplocation($location)
    {
        if ($this->generic->isLoggedInuser()) {
            
            $db = \Config\Database::connect();
            $result = $db->query("DELETE FROM pickup_loaction WHERE location_number='$location'");

            if($result == 1){
                return redirect()->back()->with("success","Location Deleted Successfully");
            }


        } else {
            return redirect()->to(site_url('/login'));
        }
    }


    private function getMenuTemplate($details)
    {
        $this->data['details'] = $details;
        return view('user/user_menu', $this->data);
    }

    private function getTopTemplate($title)
    {
        $this->data['title'] = $title;
        $db = \Config\Database::connect();
        $result = $db->query("SELECT logo FROM site_config");
        $logo = $result->getResultArray();
        $this->data["logo"] = $logo[0]["logo"];
        return view('user/user_top', $this->data);
    }
    
}
