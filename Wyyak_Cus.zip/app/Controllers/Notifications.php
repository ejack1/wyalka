<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use App\Libraries\Generic;
use CodeIgniter\Database\Config;
use Config\App;
use Config\Database;
use DateTime;

class Notifications extends BaseController
{

    private $datahdr = array();
    private $data = array();
    private $dataftr = array();

    
    public function __construct()
    { 
        $generic = new Generic();
        $this->dataftr["social"] = $generic->getsociallinks(); 
       
    }


    public function notificationlist()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Notification List";
            $details = [
                'tab' => 'Notifications',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/Notifications/notificationlist', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }


    private function getMenuTemplate($details)
    {
        $this->data['details'] = $details;
        return view('user/user_menu', $this->data);
    }

    private function getTopTemplate($title)
    {
        $this->data['title'] = $title;
        $db = \Config\Database::connect();
        $result = $db->query("SELECT logo FROM site_config");
        $logo = $result->getResultArray();
        $this->data["logo"] = $logo[0]["logo"];
        return view('user/user_top', $this->data);
    }
    
}
