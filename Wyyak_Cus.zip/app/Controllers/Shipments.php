<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use App\Models\CountryCityModel;
use App\Models\PickupLocationModel;
use App\Models\ShipmentModel;
use App\Libraries\Generic;
use CodeIgniter\Database\Config;
use Config\App;
use Config\Database;
use DateTime;

class Shipments extends BaseController
{

    private $datahdr = array();
    private $data = array();
    private $dataftr = array();

    public function __construct()
    {
        $generic = new Generic();
        $this->dataftr["social"] = $generic->getsociallinks();
    }



    public function addshipment()
    {
        if ($this->generic->isLoggedInuser()) {

            $title = "Add Shipment";
            $details = [
                'tab' => 'Shipment',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);

            $CountryCityModel = new CountryCityModel();
            $data = $CountryCityModel->select("city")->where("city !=", "")->findAll();

            for ($i = 0; $i < sizeof($data); $i++) {
                $data[$i] = $data[$i]["city"];
            }
            $this->data['cities'] = $data;
            $PickupLocationModel = new PickupLocationModel();
            $datapickup = $PickupLocationModel->select("location_number")->find();
            for ($i = 0; $i < sizeof($datapickup); $i++) {
                $datapickup[$i] = $datapickup[$i]["location_number"];
            }
            $this->data['pickuplocations'] = $datapickup;
            $id = $this->session->get("id");



            echo view('user/header', $this->datahdr);
            echo view("user/Shipment/addshipment", $this->data);

            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }

    public function addbulkshipment()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Add Bulk Shipment";
            $details = [
                'tab' => 'Shipment',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/Shipment/addbulkshipments', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function importreturnshipment()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Import Return Shipment";
            $details = [
                'tab' => 'Shipment',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/Shipment/importreturnshipment', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function todaymanifest()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Today Manifest";
            $details = [
                'tab' => 'Shipment',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/Shipment/todaymanifest', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function todayorder()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Today Orders";
            $details = [
                'tab' => 'Shipment',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/Shipment/todayorder', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function trackorder()
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "Track Orders";
            $details = [
                'tab' => 'Shipment',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);



            echo view('user/header', $this->datahdr);
            echo view('user/Shipment/trackorder', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }
    public function allshipments($status = 0)
    {
        if ($this->generic->isLoggedInuser()) {
            $title = "All Shipment";
            $details = [
                'tab' => 'Shipment',
                'class' => 'current'
            ];
            $this->datahdr['title'] = $title;

            $this->datahdr['menu_template'] = $this->getMenuTemplate($details);
            $this->datahdr['top_template'] = $this->getTopTemplate($title);

            $this->data["status"] = $status;


            echo view('user/header', $this->datahdr);
            echo view('user/Shipment/shipmentlist', $this->data);
            echo view('user/footer', $this->dataftr);
        } else {
            return redirect()->to(site_url('/login'));
        }
    }

    public function ajaxsaveshipment()
    {
        if (isset($_POST["data"])) {
            $model = new CustomerModel();
            $customer = $model->find($this->session->get('id'));
            // $customer = $customer[0];


            $ShipmentModel = new ShipmentModel();
            $data = json_decode($_POST["data"]);
            for ($i = 0; $i < sizeof($data); $i++) {
                if (!isset($data[$i][0])) {
                    break;
                }
                $upload_data = [
                    "slip_no"=> date("YmdHis"),
                    "booking_id"=> $data[$i][0],
                    "booking_mode"=> $data[$i][1],
                    "nrd"=> $data[$i][2],
                    "reciever_name"=> $data[$i][3],
                    "reciever_city"=> $data[$i][4],
                    "reciever_address"=> $data[$i][5],
                    "shippers_ac_no"=> $data[$i][6],
                    "reciever_phone"=> $data[$i][7],
                    "reciever_email"=> $data[$i][8],
                    "code"=> $data[$i][9],
                    "pieces"=> $data[$i][10],
                    "weight"=> $data[$i][11],
                    "service_id"=> $data[$i][12],
                    "shipment_val"=> $data[$i][13],
                    "status_describtion"=> $data[$i][14],
                    "second_sender_name"=> $data[$i][15],
                    "sender_name"=> $customer['name'],
                    "sender_email"=> $customer['email'],
                    "sender_phone"=> $customer['phone'],
                    "sender_city"=> $customer['city'],
                    "sender_address"=> $customer['address'],
                    
                ];
                $ShipmentModel->insert($upload_data);
            }
            $output["result"] = 1;
            echo json_encode($output);
        }
    }
    public function ajaxaddshipment()
    {
        if (isset($_POST["data"])) {
            $model = new CustomerModel();
            $customer = $model->find($this->session->get('id'));
            // $customer = $customer[0];
            $data = json_decode($_POST["data"]);
            // $data = $data[0];
            // print_r($customer);
            // exit;
            $html = "";
            for ($i = 0; $i < sizeof($data); $i++) {
                if (!isset($data[$i][0])) {
                    break;
                }
                $html .= '<style>
                table {
                    font-family: arial, sans-serif;
                    border-collapse: collapse;
                    width: 100%;
                }

                td, th {
                    border: 1px solid #dddddd;
                    text-align: left;
                    padding: 8px;
                } 
                </style>
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4>Selected Booking Details</h4>
                            </div>
                            <div class="panel-body">
                                <div class="col-md-6 borderright">
                                    <h3 class="defaultcolor boldfont">Parcel Description</h3>
                                    <table> 
                                        <tr>
                                            <th><strong>Origin</strong></th>
                                            <td>' . $this->checknull($data[$i][4]) . '</td>
                                            <th><strong>City</strong></th>
                                            <td>' . $this->checknull($data[$i][4]) . '</td>
                                        </tr>
                                        <tr>
                                            <th><strong>Unique Id</strong></th>
                                            <td>2369541</td>
                                            <th><strong>Reference No</strong></th>
                                            <td>' . $this->checknull($data[$i][0]) . '</td>
                                        </tr>
                                        <tr>
                                            <th><strong>Product Type</strong></th>
                                            <td>' . $this->checknull($data[$i][2]) . '</td>
                                            <th><strong>Services</strong></th>
                                            <td>' . $this->checknull($data[$i][12]) . '</td> 
                                        </tr>
                                    </table>  
                                </div>
                                <div class="col-md-6 borderright">
                                    <h3 class="defaultcolor boldfont">Parcel Details</h3>
                                    <table> 
                                        <tr>
                                            <th><strong>Total Amount</strong></th>	<th><strong>Weight</strong></th>
                                            <td>' . $this->checknull($data[$i][11]) . ' KG</td>
                                        </tr>
                                        <tr>
                                            <th><strong>Parcel Quantity</strong></th>
                                            <td>' . $this->checknull($data[$i][10]) . '</td>
                                            <th><strong>Shipment Value</strong></th><td>' . $this->checknull($data[$i][13]) . '</td>	
                                        </tr>	<tr>
                                            <th><strong>Services</strong></th>
                                            <td>' . $this->checknull($data[$i][12]) . '</td>
                                            <th><strong>Description</strong></th>
                                            <td>' . $this->checknull($data[$i][14]) . '</td> 
                                        </tr> 
                                        <tr>
                                            
                                            <th><strong>Second Sender Name</strong></th>
                                            <td>' . $this->checknull($data[$i][15]) . '</td> 
                                        </tr> 
                                    </table>  </div>
                            </div>
                        </div>
                    </div>
                </div>  
                <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h2><i class="fa fa-long-arrow-up"></i> Sender Details</h2>
                            </div>
                            <div class="panel-body">
                                <div><span class="black boldfont">Name:</span>' . $customer['name'] . '</div>
                                <div><span class="black boldfont">Mobile Number:</span> ' . $customer['phone'] . '</div>
                                <div><span class="black boldfont">E-Mail:</span> ' . $customer['email'] . '</div>
                                <div><span class="black boldfont">City:</span>' . $this->getcityname($customer['city']) . '</div>
                                <div><span class="black boldfont">Unique Id Account:</span>' . $customer['uniqueid'] . '</div>
                                <div><span class="black boldfont">Address:</span>' . $customer['address'] . ' </div>
                                <div><span class="black boldfont">Country:</span> ' . $this->getcountryname($customer['city']) . ' </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h2><i class="fa fa-long-arrow-down"></i>Receiver Details</h2>
                            </div>
                            <div class="panel-body">
                                <div><span class="black boldfont">Name:</span>' . $this->checknull($data[$i][3]) . '</div>
                                <div><span class="black boldfont">Mobile:</span> ' . $this->checknull($data[$i][7]) . '</div>
                                <div><span class="black boldfont">E-Mail:</span> ' . $this->checknull($data[$i][8]) . '</div>
                                <div><span class="black boldfont">City:</span>' . $this->checknull($data[$i][4]) . '</div>
                                <div><span class="black boldfont">Address:</span> ' . $this->checknull($data[$i][5]) . '</div>
                                <div><span class="black boldfont">Country:</span>' . $this->getcountry($data[$i][4]) . '</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>&nbsp;</div> 
            <div>&nbsp;</div>
             
            </div>
            </div>
            </div>
            </div>
            </div>
            <div>&nbsp;</div>
    ';
            }
            $html .= '<div class="col-md-6">
            <div class="form-group" > 
                <button type="button" class="btn btn-sm btn-primary" name="save" onclick="edit_shipment();"  value="Submit"  >Edit </button> 
            </div>
        </div><div class="col-md-6">
            <div class="form-group" > 
                <button type="button" class="btn btn-sm btn-primary" name="save" onclick="save_shipment();"  value="Submit"  >Submit </button> 
            </div>
        </div>';
            echo json_encode($html);
        }
    }
    public function checknull($value)
    {
        if (isset($value)) {
            return $value;
        } else {
            return "-";
        }
    }
    public function getcountry($city)
    {
        $CountryCityModel = new CountryCityModel();
        $data = $CountryCityModel->select(["id", "country"])->where(['city' => $city])->find();
        return $data[0]["country"];
    }
    public function getcountryname($city)
    {
        $CountryCityModel = new CountryCityModel();
        $data = $CountryCityModel->select(["id", "country"])->where(['id' => $city])->find();
        return $data[0]["country"];
    }
    public function getcityname($city)
    {
        $CountryCityModel = new CountryCityModel();
        $data = $CountryCityModel->select(["id", "city"])->where(['id' => $city])->find();
        return $data[0]["city"];
    }

    private function getMenuTemplate($details)
    {
        $this->data['details'] = $details;
        return view('user/user_menu', $this->data);
    }

    private function getTopTemplate($title)
    {
        $this->data['title'] = $title;
        $db = \Config\Database::connect();
        $result = $db->query("SELECT logo FROM site_config");
        $logo = $result->getResultArray();
        $this->data["logo"] = $logo[0]["logo"];
        return view('user/user_top', $this->data);
    }
}
