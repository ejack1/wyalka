<?php 
namespace App\Libraries;
require getcwd() . '/app/Libraries/twilio-php-main/src/Twilio/autoload.php';        
use Twilio\Rest\Client;

use Config\Database;


class Generic {
    
    protected $session;
    
    public function __construct(){
        $this->session = \Config\Services::session();
    }
    
    public function  makeSafe($content){
        return strip_tags($content);
    }
    public function getsociallinks(){
        $db = \Config\Database::connect();
        $data = $db->query("Select * from generalsetting ");
        $data = $data->getResultArray();
        return $data[0];
    }
   

    function startSessionuser($user){
        
        $data = [
            'id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name'],
            'phone' => $user['phone'],
         
            
        ];
                
        $this->session->set($data);
        
    }

    
    
    
    
    public function isRemoteServer(){
        $whitelist = array(
            '127.0.0.1',
            '::1'
        );

        if(!in_array($_SERVER['REMOTE_ADDR'], $whitelist)){
            return 1;
        }
        else{
            return 0;
        }
    }
    

    function isLoggedInuser(){
        if(empty($this->session->get('id'))){
            return false; 
        }
        else{
            return true;
        }
    }

   
    
    
    function getUserTypeByTypeId($type_id){
        switch($type_id):
            case 1:
                return "Administrator";
        endswitch;
    }
    
    function slugify($text) {
        // replace non letter or digits by -
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);

        // transliterate
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

        // remove unwanted characters
        $text = preg_replace('~[^-\w]+~', '', $text);

        // trim
        $text = trim($text, '-');

        // remove duplicate -
        $text = preg_replace('~-+~', '-', $text);

        // lowercase
        $text = strtolower($text);

        if (empty($text)) {
            return 'n-a';
        }

        return $text;
    }

}

?>