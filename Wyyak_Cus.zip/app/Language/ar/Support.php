<?php

// override core en language system validation or define your own en language validation message
return [

    "Account_Manager_Info" => "معلومات مدير الحساب" ,
    "Support_Center" => "مركز الدعم الفني" ,
    "Help" => "نحن هنا لمساعدتك.." ,
    "Create_a_ticket" => "انشاء تذكرة" ,
    
    
    
   
];