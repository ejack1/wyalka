<?php

// override core en language system validation or define your own en language validation message
return [

    "Today_Manifest" => "منافيست اليوم" ,
    "Date" => "تاريخ" ,
    "Get_Manifest" => "طباعة المنافيسة " ,
    "Print_Manifest" => "تصدير المنافيست" ,
    "Awb_No" => "رقم البوليصة" ,
    "Booking_Id" => "هوية الحجز" ,
    "Status" => "الحالة" ,
    "Description" => "الوصف" ,
    "Customer_name" => "اسم العميل" ,
    
    
    
    
    
   
];