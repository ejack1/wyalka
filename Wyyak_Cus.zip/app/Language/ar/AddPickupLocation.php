<?php

// override core en language system validation or define your own en language validation message
return [

    "Add_Pickup_Location" => "اضافة موقع للبيك اب" ,
    "Pickup_Location" => "موقع البيك اب" ,
    "Add_Location" => "اضافة موقع" ,
    "Cancel" => "الغاء" ,
   
   
    
    
   
];