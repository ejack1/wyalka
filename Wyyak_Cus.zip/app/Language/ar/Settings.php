<?php

// override core en language system validation or define your own en language validation message
return [

    "Dashboard" => "لوحة القيادة" ,
    "My_Profile" => "ملفي" ,
    "Change_Password" => "غير كلمة السر" ,
    "Log_Out" => "تسجيل خروج" ,
    
   
];