<?php

// override core en language system validation or define your own en language validation message
return [

    "Show_Pickup_Request" => "عرض طلب بيك اب" ,
    "SrNo" => "الرقم التسلسلي." ,
    "Date" => "التاريخ" ,
    "Time" => "الوقت" ,
    "No_of_Shipment" => "عدد ال الشحنة" ,
    "Lat_Lang" => "اللات لانج" ,
    "Confirmation" => "التأكيد" ,
    
   
    
    
   
];