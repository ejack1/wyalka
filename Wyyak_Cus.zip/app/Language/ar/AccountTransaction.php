<?php

// override core en language system validation or define your own en language validation message
return [

    "Account_Transaction" => "المالية" ,
    "Date" => "تاريخ" ,
    "Export_to_excel" => "تصدير للاكسل" ,
    "Submit" => "تصدير للاكسل" ,
    "SrNo" => "الرقم التسلسلي" ,
    "Delivery_Date" => "تاريخ التوصيل" ,
    "Awb_No" => "رقم البوليصة" ,
    "Cod_Value" => "قيمة الشحنة" ,
    "Shipment_Amount" => "سعر الشحنة" ,
    "Collect_Fees" => "رسوم التحصيل" ,
    "Return_Fees" => "رسوم المرتجعات" ,
    "Status" => "الحالة" ,
    "Pay_Status" => "حالة الدفع" ,
    "Total" => "لمجموع" ,
    
    
    
    
    
   
];