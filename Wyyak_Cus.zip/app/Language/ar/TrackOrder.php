<?php

// override core en language system validation or define your own en language validation message
return [

    "Track_search" => "البحث في ارقام التتبع" ,
    "Track_Now" => "تتبع الان" ,
    "Cancel" => "الغاء " ,
    "placeholder" => "AWB Number search I Ref Number Search" ,
    
    
    
    
   
];