<?php

// override core en language system validation or define your own en language validation message
return [

    "Dashboard" => "لوحة القيادة" ,
    "Tickets_Management" => "إدارة التذاكر" ,
    "Add_Tickets" => "أضف تذاكر" ,
    "All_Tickets" => "جميع التذاكر" ,
    "Shipment_Management" => "إدارة الشحن" ,
    "Add_Shipment" => "أضف الشحنات" ,
    "Add_Bulk_Shipments" => "أضف الشحنات المجمعة" ,
    "Add_Return_Shipments" => "أضف شحنات المرتجعات" ,
    "Today_Manifest" => "بيان اليوم" ,
    "Today_Orders" => "أوامر اليوم" ,
    "Track_Orders" => "تتبع الطلبات" ,
    "Shipment_List" => "قائمة الشحن" ,
    "Pickup_Management" => "إدارة الالتقاط" ,
    "Add_Pickup_Location" => "أضف موقع الالتقاط" ,
    "Pickup_Location" => "اختر موقعا" ,
    "Report_Management" => "إدارة التقارير" ,
    "Account_Transaction" => "معاملة الحساب" ,
    "Pickup_Request" => "طلب بيك اب" ,
    "Add_Pickup_Request" => "إضافة طلب لاقط" ,
    "Show_Pickup_Request" => "إظهار طلب الالتقاط" ,
    "Client_Performance" => "أداء العميل" ,
    "Support" => "يدعم" ,
    "Account_Manager" => "إدارة حساب المستخدم" ,
    "Notifications" => "إشعارات" ,
    "Notifications_List" => "قائمة الإخطارات" ,
    "Api_Management" => "إدارة API" ,
    "Api_Documents" => "مستندات Api" ,
    
   
];