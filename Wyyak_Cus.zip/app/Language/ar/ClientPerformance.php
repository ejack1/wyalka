<?php

// override core en language system validation or define your own en language validation message
return [

    "Client_Performance" => " الانتاجية",
    "Date" => " تاريخ",
    "Submit" => "تنفيذ ",
    "SrNo" => "الرقم التسلسلي",
    "Awb_No" => "رقم البوليصة",
    "Refrence_No" => "رقم المرجع.",
    "Entry_Date" => "تاريخ الادخال",
    "Origin" => "من",
    "Destination" => "الى",
    "Pickup_Date" => "تاريخ البيك اب",
    "Schedule_Date" => "تاريخ الجدولة",
    "On_Hold" => "موقوفة مؤقتا",
    "Delivery_Attempts" => "محاولات التوصيل",
    "Call_Attempts" => "محاولات الاتصال",
    "Status" => "الحالة",
    
    
   
];