<?php

// override core en language system validation or define your own en language validation message
return [

    "name" => "اسم" ,
    "UID_Account_Number" => "رقم حساب UID" ,
    "Company" => "شركة" ,
    "Address" => "عنوان" ,
    "City" => "مدينة" ,
    "Mobile" => "التليفون المحمول" ,
    "Alternative_Number" => "عدد البديل" ,
    "Email_Address" => "عنوان بريد الكتروني" ,
    "Bank_Name" => "اسم البنك" ,
    "Bank_Account_Number" => "رقم الحساب المصرفي" ,
    "IBAN_Account_Number" => "رقم حساب الآيبان" ,
    "Update" => "تحديث" ,
    "Basic_Information" => "معلومات اساسية" ,
    
    

];
