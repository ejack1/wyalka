<?php

// override core en language system validation or define your own en language validation message

return [

    "Reference" => " الرقم المرجعي" ,
    "Shipper_Reference#" => "الرقم المرجعي للمرسل#" ,
    "Product/Type" => " انواع المنتجات" ,
    "Weight(GM)" => "الوزن(GM)" ,
    "Booking_Mode" => " وضع الحجز" ,
    "Pickup_Location" => "موقع البيك اب" ,
    "Destination" => "الى" ,
    "Consignor_Name" => "اسم المستلم" ,
    "Consignor_Address" => "عنوان المستلم" ,
    "Consignor_Mobile" => " جوال المستلم" ,
    "Consignor_E-mail" => " البريد الالكتروني للمستلم" ,
    "Description" => "الوصف" ,
    "COD_Amount" => " مبلغ الدفع عند الاستلام" ,
    "Service" => "الخدمة" ,
    "Parcel_Value" => "قيمة الشحنة" ,
    "Second_Sender_Details" => " تفاصيل المرسل ثان" ,
    "Import_CSV_Shipment" => "تحميل ملف CSV" ,
    "NOTE" => "ملاحظات" ,
    "NOTE_des" => "لاستيراد الشحنات السائبة ، استخدم ميزة الاستيراد هذه. فيما يلي الأعمدة التي يجب أن تكون لديك وفقًا للرقم التسلسلي في ملف Excel CSV. 2. يجب عليك إدخال paymode على النحو التالي: CC أو COD" ,
    "Import_File" => "تحميل ملف" ,
    "Import_Shipment" => " استيراد شحنات" ,
    "Add_Shipment" => "أضف الشحنات" ,
    
    
    
   
];