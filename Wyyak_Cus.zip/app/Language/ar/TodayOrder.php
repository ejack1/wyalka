<?php

// override core en language system validation or define your own en language validation message
return [

    "Today_Order" => "شحنات اليوم" ,
    "Date" => " تاريخ" ,
    "Reference_Number" => "الرقم المرجعي" ,
    "Tracking_Number" => "رقم التتبع" ,
    "Status" => "الحالة" ,
    "Destination" => "الى" ,
    "Export_to_excel" => "تصدير الى اكسل" ,
    "Label4" => "ملصق 4*6" ,
    "Print_Label_A4" => "طباعة ملصق A4 " ,
    "Total_Shipment" => "مجموع الشحنات " ,
    "Submit" => "تنفيذ" ,
    "SrNo" => "الرقم التسلسلي" ,
    "Awb_No" => "رقم البوليصة" ,
    "Refrence_No" => "رقم المرجع." ,
    "Shipper_Refrence" => "الرقم المرجعي للمرسل#" ,
    "Entry_Date" => "تاريخ الادخال" ,
    "Origin" => "من" ,
    "Pickup_Date" => "تاريخ البيك اب" ,
    "Pickup_Time" => "توقيت إستلام الشحنة من المرسل" ,
    "Schedule_Date" => "تاريخ الجدولة" ,
    "On_Hold" => "موقوفة مؤقتا" ,
    "On_Reason" => "سبب عدم التوصيل" ,
    "Delivery_Attempts" => "محاولات التوصيل" ,
    "Call_Attempts" => "محاولات الاتصال" ,
    "Status" => "الحالة" ,
    "Deliver_Date" => "تاريخ التوصيل" ,
    "Action" => "الاجراء" ,
   
    
    
    
    
    
   
];