<?php

// override core en language system validation or define your own en language validation message
return [

    
    "Update_Password" => "تطوير كلمة السر",
    "Old_Password" => "كلمة سر قديمة",
    "Confirm_Password" => "تأكيد كلمة المرور",
    "New_Password" => "كلمة المرور الجديدة",
    
   
];