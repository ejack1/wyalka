<?php

// override core en language system validation or define your own en language validation message
return [

    "Add_Pickup_Request" => "طلب بيك اب اضافة" ,
    "Time" => "الوقت" ,
    "Date" => "التاريخ" ,
    "No_of_Shipment" => "عدد ال الشحنة" ,
    "Submit" => "تنفيذ" ,
   
    
    
   
];