<?php

// override core en language system validation or define your own en language validation message
return [

    "Old_AWB_No" => "الشحنات القديمة" ,
    "Weight" => "الوزن(GM)" ,
    "Pieces" => "عدد القطع" ,
    "Import_File" => "تحميل ملف" ,
    "Add_Return_Shipment" => "اضافة شحنات مرتجعة" ,
    "Return_CSV_Shipment" => "قالب شحنات الرجيع سي اس في" ,
    "Note_des" => "لاستيراد شحنات مجمعة ، استخدم ميزة الاستيراد هذه. فيما يلي الأعمدة التي يجب أن تكون لديك وفقًا للرقم التسلسلي بتنسيق excel csv. 2. يجب إدخال paymode كـ: CASH أو COD" ,
    "Note" => "ملاحظة" ,
    
    
    
    
    
   
];