<?php

// override core en language system validation or define your own en language validation message
return [

    "Ticket_Manager" => "ادارة التذاكر" ,
    "AWB_No" => "رقم بوليصة الشحن" ,
    "Ticket_Number" => "رقم التذكرة" ,
    "Subject" => "العنوان" ,
    "Update_Date" => "تاريخ التحديث" ,
    "Status" => "الحالة" ,
    
    
    
    
   
];