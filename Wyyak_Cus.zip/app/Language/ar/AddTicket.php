<?php

// override core en language system validation or define your own en language validation message
return [

    "Reason" => "السبب" ,
    "AWB_No" => "رقم بوليصة الشحن" ,
    "Description" => "وصف" ,
    "Cancel" => "يلغي" ,
    "Submit" => "إرسال" ,
    "Support" => "يدعم" ,
    "Drop_Your_Reason" => "إسقاط السبب الخاص بك" ,
    "Complaint_employee"=>"شكوى ضد موظف (S)",
    "Billing_payment"=>"دفع الفواتير",
    "Contact_center_issue"=>"مشكلة مركز الاتصال",
    "Courier_driving"=>"ساعي القيادة",
    "PDP"=>"بيك آب / التسليم / قضية شخصية",
    "Service_issue"=>"مشكلة الخدمة",
    "Website"=>"موقع الكتروني",
    "Support_request"=>"طلب دعم",
    "Share_suggestion"=>"مشاركة الاقتراح",
    "Please_select"=>"الرجاء الاختيار",
    
    
    
   
];

