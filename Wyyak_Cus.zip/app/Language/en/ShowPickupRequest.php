<?php

// override core en language system validation or define your own en language validation message
return [

    "Show_Pickup_Request" => "Show Pickup Request" ,
    "SrNo" => "Sr.No" ,
    "Date" => "Date" ,
    "Time" => "Time" ,
    "No_of_Shipment" => "No of Shipment" ,
    "Lat_Lang" => "Lat Lang" ,
    "Confirmation" => "Confirmation" ,
    
   
    
    
   
];