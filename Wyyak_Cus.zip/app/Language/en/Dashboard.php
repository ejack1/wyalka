<?php

// override core en language system validation or define your own en language validation message
return [

    "Today_Dashboard" => "Today's Dashboard" ,
    "New_Shipment" => "New Shipment" ,
    "Today_OFD" => "Today's OFD" ,
    "Scheduled" => "Scheduled" ,
    "Not_Delivered" => "Not Delivered" ,
    "Pickup_Collected" => "Pick Up Collected" ,
    "OFD_NOT" => "OFD/Not Processed" ,
    "Return" => "Return" ,
    "Shelve" => "Shelve" ,
    "Shipment_Forward" => "Shipment Forward/Arrival" ,
    "Hold" => "Hold For Pickup" ,
    "Delivered" => "Delivered" ,
    "Received_Inbound" => "Received Inbound" ,
    "Ready_for" => "Ready for Delivery" ,
    "Daily_OFD_Details" => "Daily OFD Details" ,
    "Monthly_Shipment_Details" => "Monthly Shipment Details" ,
    
    
    

];