<?php

// override core en language system validation or define your own en language validation message
return [

    "Client_Performance" => "Client Performance",
    "Date" => "Date",
    "Submit" => "Submit",
    "SrNo" => "Sr.No.",
    "Awb_No" => "Awb No",
    "Refrence_No" => "Refrence No.",
    "Entry_Date" => "Entry Date",
    "Origin" => "Origin",
    "Destination" => "Destination",
    "Pickup_Date" => "Pickup Date",
    "Schedule_Date" => "Schedule Date",
    "On_Hold" => "On Hold",
    "Delivery_Attempts" => "Delivery Attempts",
    "Call_Attempts" => "Call Attempts",
    "Status" => "Status",
    
    
   
];