<?php

// override core en language system validation or define your own en language validation message
return [

    "Track_search" => "Track search" ,
    "Track_Now" => "Track Now" ,
    "Cancel" => "Cancel" ,
    "Submit" => "Submit" ,
    "placeholder" => "AWB Number search I Ref Number Search" ,
    
    
    
    
   
];