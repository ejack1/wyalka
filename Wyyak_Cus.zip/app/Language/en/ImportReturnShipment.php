<?php

// override core en language system validation or define your own en language validation message
return [

    "Return_csv_Shipement" => "Return csv Shipement" ,
    "Old_AWB_No" => "Old AWB No." ,
    "Weight" => "Weight(GM)" ,
    "Pieces" => "Pieces" ,
    "Import_File" => "Import File" ,
    "Add_Return_Shipment" => "Add Return Shipment" ,
    "Return_CSV_Shipment" => "Return CSV Shipment" ,
    "Note_des" => "To import bulk shipments use this import feature. Below are the columns you must have according to serial number in the excel csv file. 2. You must have to insert paymode as : CASH or COD." ,
    "Note" => "Note" ,
    
    
    
    
    
   
];