<?php

// override core en language system validation or define your own en language validation message
return [

    "Today_Manifest" => "Today Manifest" ,
    "Date" => "Date" ,
    "Print_Manifest" => "Print Manifest" ,
    "Get_Manifest" => "Get Manifest" ,
    "Awb_No" => "Awb No" ,
    "Booking_Id" => "Booking Id" ,
    "Status" => "Status" ,
    "Description" => "Description" ,
    "Customer_name" => "Customer name" ,
    
    
    
    
    
   
];