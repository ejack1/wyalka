<?php

// override core en language system validation or define your own en language validation message
return [

    "Update_Password" => "Update Password",
    "Old_Password" => "Old Password",
    "Confirm_Password" => "Confirm Password",
    "New_Password" => "New Password",
    
   
];