<?php

// override core en language system validation or define your own en language validation message
return [

    "name" => "Name" ,
    "UID_Account_Number" => "UID Account Number" ,
    "Company" => "Company" ,
    "Address" => "Address" ,
    "City" => "City" ,
    "Mobile" => "Mobile" ,
    "Alternative_Number" => "Alternative Number" ,
    "Email_Address" => "Email Address" ,
    "Bank_Name" => "Bank Name" ,
    "Bank_Account_Number" => "Bank Account Number" ,
    "IBAN_Account_Number" => "IBAN Account Number" ,
    "Update" => "Update" ,
    "Basic_Information" => "Basic Information" ,
    
    

];
