<?php

// override core en language system validation or define your own en language validation message
return [

    "Dashboard" => "Dashboard" ,
    "Tickets_Management" => "Tickets Management" ,
    "Add_Tickets" => "Add Tickets" ,
    "All_Tickets" => "All Tickets" ,
    "Shipment_Management" => "Shipment Management" ,
    "Add_Shipment" => "Add Shipment" ,
    "Add_Bulk_Shipments" => "Add Bulk Shipments" ,
    "Add_Return_Shipments" => "Import Return Shipments" ,
    "Today_Manifest" => "Today Manifest" ,
    "Today_Orders" => "Today Orders" ,
    "Track_Orders" => "Track Orders" ,
    "Shipment_List" => "Shipment List" ,
    "Pickup_Management" => "Pickup Management" ,
    "Add_Pickup_Location" => "Add Pickup Location" ,
    "Pickup_Location" => "Pickup Location" ,
    "Report_Management" => "Report Management" ,
    "Account_Transaction" => "Account Transaction" ,
    "Pickup_Request" => "Pickup Request" ,
    "Add_Pickup_Request" => "Add Pickup Request" ,
    "Show_Pickup_Request" => "Show Pickup Request" ,
    "Client_Performance" => "Client Performance" ,
    "Support" => "Support" ,
    "Account_Manager" => "Account Manager" ,
    "Notifications" => "Notifications" ,
    "Notifications_List" => "Notifications List" ,
    "Api_Management" => "Api Management" ,
    "Api_Documents" => "Api Documents" ,
    
   
];