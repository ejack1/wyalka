<?php

// override core en language system validation or define your own en language validation message
return [

    "Notification_List" => "Notification List" ,
    "SrNo" => "Sr.No" ,
    "Subject" => "Subject" ,
    "Description" => "Description" ,
    "Entry_Date" => "Entry Date" ,
    "Expiry_Date" => "Expiry Date" ,
    
    
    
    
    
   
];