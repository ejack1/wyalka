<?php

// override core en language system validation or define your own en language validation message
return [

    "Add_Pickup_Request" => "Add Pickup Request" ,
    "Time" => "Time" ,
    "Date" => "Date" ,
    "No_of_Shipment" => "No of Shipment" ,
    "Submit" => "Submit" ,
   
    
    
   
];