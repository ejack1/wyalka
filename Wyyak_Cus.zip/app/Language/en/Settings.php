<?php

// override core en language system validation or define your own en language validation message
return [

    "Dashboard" => "Dashboard" ,
    "My_Profile" => "My Profile" ,
    "Change_Password" => "Change Password" ,
    "Log_Out" => "Log Out" ,
    
   
];