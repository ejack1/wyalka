<?php

// override core en language system validation or define your own en language validation message
return [

    "Account_Manager_Info" => "Account Manager Info" ,
    "Support_Center" => "Support Center" ,
    "Help" => "We're here to help.." ,
    "Create_a_ticket" => "Create a ticket" ,
    
    
    
   
];