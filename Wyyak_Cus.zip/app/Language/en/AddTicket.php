<?php

// override core en language system validation or define your own en language validation message
return [

    "Reason" => "Reason" ,
    "AWB_No" => "AWB No" ,
    "Description" => "Description" ,
    "Cancel" => "Cancel" ,
    "Submit" => "Submit" ,
    "Support" => "Support" ,
    "Drop_Your_Reason" => "Drop Your Reason" ,
    "Complaint_employee"=>"Complaint employee(s)",
    "Billing_payment"=>"Billing payment",
    "Contact_center_issue"=>"Contact center issue",
    "Courier_driving"=>"Courier driving",
    "PDP"=>"Pickup/delivery/personal issue",
    "Service_issue"=>"Service issue",
    "Website"=>"Website",
    "Support_request"=>"Support request",
    "Share_suggestion"=>"Share suggestion",
    "Please_select"=>"Please Select",
    
    
   
];