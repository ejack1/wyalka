<?php

// override core en language system validation or define your own en language validation message
return [

    "Today_Order" => "Today Order" ,
    "Date" => "Date" ,
    "Reference_Number" => "Reference Number" ,
    "Tracking_Number" => "Tracking Number" ,
    "Status" => "Status" ,
    "Destination" => "Destination" ,
    "Export_to_excel" => "Export to Excel" ,
    "Label4" => "Label4*6" ,
    "Print_Label_A4" => "Print Label A4" ,
    "Total_Shipment" => "Total Shipment" ,
    "Submit" => "Submit" ,
    "SrNo" => "Sr.No." ,
    "Awb_No" => "Awb No" ,
    "Refrence_No" => "Refrence No." ,
    "Shipper_Refrence" => "Shipper Refrence#" ,
    "Entry_Date" => "Entry Date" ,
    "Origin" => "Origin" ,
    "Pickup_Date" => "Pickup Date" ,
    "Pickup_Time" => "Pickup Time" ,
    "Schedule_Date" => "Schedule Date" ,
    "On_Hold" => "On Hold" ,
    "On_Reason" => "On Reason" ,
    "Delivery_Attempts" => "Delivery Attempts" ,
    "Call_Attempts" => "Call Attempts" ,
    "Status" => "Status" ,
    "Deliver_Date" => "Deliver Date" ,
    "Action" => "Action" ,
    "Shipment_List" => "Shipment List" ,
   
    
    
    
    
    
   
];