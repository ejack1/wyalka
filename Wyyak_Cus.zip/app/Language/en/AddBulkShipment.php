<?php

// override core en language system validation or define your own en language validation message
return [

    "Reference" => "Reference" ,
    "Shipper_Reference#" => "Shipper Reference#" ,
    "Product/Type" => "Product/Type" ,
    "Weight(GM)" => "Weight(GM)" ,
    "Booking_Mode" => "Booking Mode" ,
    "Pickup_Location" => "Pickup Location" ,
    "Destination" => "Destination" ,
    "Consignor_Name" => "Consignor Name" ,
    "Consignor_Address" => "Consignor Address" ,
    "Consignor_Mobile" => "Consignor Mobile" ,
    "Consignor_E-mail" => "Consignor E-mail" ,
    "Description" => "Description" ,
    "COD_Amount" => "COD Amount" ,
    "Service" => "Service" ,
    "Parcel_Value" => "Parcel Value" ,
    "Second_Sender_Details" => "Second Sender Details" ,
    "Import_CSV_Shipment" => "Import CSV Shipment" ,
    "NOTE" => "NOTE" ,
    "NOTE_des" => "To import bulk shipments use this import feature. Below are the columns you must have according to serial number in the excel csv file.2. You must have to insert paymode as : CC or COD" ,
    "Import_File" => "Import File" ,
    "Import_Shipment" => "Import Shipment" ,
    "Add_Shipment" => "Import CSV Shipment" ,
    
    
    
   
];