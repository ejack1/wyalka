<?php

// override core en language system validation or define your own en language validation message
return [

    "Ticket_Manager" => "Ticket Manager" ,
    "AWB_No" => "AWB No." ,
    "Ticket_Number" => "Ticket Number" ,
    "Subject" => "Subject" ,
    "Update_Date" => "Update Date" ,
    "Status" => "Status" ,
    
    
    
    
   
];