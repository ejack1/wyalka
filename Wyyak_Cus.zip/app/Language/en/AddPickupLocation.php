<?php

// override core en language system validation or define your own en language validation message
return [

    "Add_Pickup_Location" => "Add Pickup Location" ,
    "Pickup_Location" => "Pickup Location" ,
    "Add_Location" => "Add Location" ,
    "Cancel" => "Cancel" ,
   
   
    
    
   
];