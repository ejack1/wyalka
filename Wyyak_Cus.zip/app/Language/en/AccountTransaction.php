<?php

// override core en language system validation or define your own en language validation message
return [

    "Account_Transaction" => "Account Transaction" ,
    "Date" => "Date" ,
    "Export_to_excel" => "Export to excel" ,
    "Submit" => "Submit" ,
    "SrNo" => "Sr.No." ,
    "Delivery_Date" => "Delivery Date" ,
    "Awb_No" => "Awb No" ,
    "Cod_Value" => "Cod Value" ,
    "Shipment_Amount" => "Shipment Amount" ,
    "Collect_Fees" => "Collect Fees" ,
    "Return_Fees" => "Return Fees" ,
    "Status" => "Status" ,
    "Pay_Status" => "Pay Status" ,
    "Total" => "Total" ,
    
    
    
    
    
   
];