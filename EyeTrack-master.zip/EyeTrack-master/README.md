# EyeTrack

TODO:
- start on sound trigger
- experiment loop with nice interface