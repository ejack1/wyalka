package com.fastcoo.fastcoowms.viewmodel;

import androidx.lifecycle.ViewModel;

public class ShipmentInfoViewModel extends ViewModel {
}
