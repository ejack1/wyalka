package com.fastcoo.fastcoowms.viewmodel;

import androidx.lifecycle.ViewModel;

public class InBoundViewModel extends ViewModel {
}
