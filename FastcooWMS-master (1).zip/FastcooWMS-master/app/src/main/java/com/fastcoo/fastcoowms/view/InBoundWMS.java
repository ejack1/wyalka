package com.fastcoo.fastcoowms.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.fastcoo.fastcoowms.R;

public class InBoundWMS extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_bound_w_m_s);
    }
}