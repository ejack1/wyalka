package com.fastcoo.fastcoopickerapp.Interface;

public interface UpdateCount {
    void getCount(double count);
}
